package sample;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.CacheHint;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static javafx.scene.shape.Shape.intersect;
public class display implements Serializable {
    //Group game_objects = new Group();
    //Group game_objects_ball = new Group();
    //double Y=-512.5;
    //square sq =new square(50,2200);
    //circle c =new circle(300,2200);
    // int Y_axis=50;
    Text text= new Text();
    {
        text.setText("0");
        text.setX(20);
        text.setY(40);
        text.setFill(Color.WHITE);
        Font font=Font.loadFont(getClass()
                .getResourceAsStream("fonts/font7.ttf"), 50);
        text.setFont(font);
    }
    Player player;
    int flag;
    int points=0;
    double ballY=450;
    int time=5000;
    ball ball;
    Timeline timeline6;
    {ball=new ball(450);}
   // Button  Button4=new Button();
    // gameObjects obj =new gameObjects();
    Group objects =new Group();
    {
        //objects.getChildren().add(Button4);
        objects.getChildren().add(ball.ball);
        objects.getChildren().add(text);
    }
    List<gameObjects> l2=new ArrayList<>() ;

    {
        l2.add(new circle(200, 5000));
        objects.getChildren().add(l2.get(0).obstacle);
        l2.add(new cross(-200, 5000));
        objects.getChildren().add(l2.get(1).obstacle);
        l2.add(new square(-600, 5000));
        objects.getChildren().add(l2.get(2).obstacle);
        l2.add(new double_cross(-1000, 5000));
        objects.getChildren().add(l2.get(3).obstacle);
    }

   /* List<obstacles>   l1 = new ArrayList<>();
    {
        l1.add(c);
        l1.add(sq);
        // l1.add(sq);
    }*/
    Scene scene2;


    //Scene scene3=new Scene(game_objects_ball, 250, 300, Color.BLACK);
    Stage stage;
    public display(Stage stage,List<gameObjects> list,Player player,double y){
        flag=1;
        play();
        timeline6.stop();
        this.player=player;
        text.setText(Integer.toString(player.points));
        this.stage=stage;
        ball.ball.setCenterY(y);
        //l2.addAll(list);
        if(list.size()!=0)
        {
            for(int i=0;i<l2.size();i++)
            {
                objects.getChildren().remove(2, objects.getChildren().size());
            }
            l2.removeAll(l2);
            l2.addAll(list);
        }
        for(int i=0;i<list.size();i++)
        {
            objects.getChildren().add(list.get(i).obstacle);
        }
    }
    public display(Stage stage,Player player){
        this.player=player;
        text.setText("0");
        this.stage=stage;
        flag=0;
        {
            //l2.add(new circle(200,5000));
            //objects.getChildren().add(l2.get(0).obstacle);

            //l2.add(new double_circle(-400,5000));
            //objects.getChildren().add(l2.get(1).obstacle);
            //l2.add(new Switch(0,2200));
            //objects.getChildren().add(l2.get(2).obstacle);
            //l2.add(new cross(-400,2200));
            //  objects.getChildren().add(l2.get(2).obstacle);
            // l2.add(new circle(-650,2200));
            // objects.getChildren().add(l2.get(3).obstacle);
            //  l2.add(new circle(-900,2200));
            // objects.getChildren().add(l2.get(4).obstacle);
//        l1.add(sq);
        }
    }
    {
//        Button4.setPrefSize(70,70);
//        Button4.setText("||");
//        Font font= Font.loadFont(getClass().getResourceAsStream("fonts/font3.ttf"), 25);
//        Button4.setFont(font);
//        Button4.setStyle("-fx-text-fill: black; ");
//        Button4.setLayoutX(375);
//        Button4.setLayoutY(10);
//        BackgroundImage backgroundImage = new BackgroundImage( new Image( getClass().getResource("17.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
//        Background background = new Background(backgroundImage);
//        BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("16.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
//        Background background2 = new Background(backgroundImage1);
//        Button4.setOnMouseEntered(e -> Button4.setBackground(background2));
//        Button4.setOnMouseExited(e -> Button4.setBackground(background));
//        Button4.setBackground(background);
//        Button4.setOnMouseClicked(e -> {
//            /*mainPage p=new mainPage(stage);
//            stage.setScene(p.scene);
//            stage.show();*/
//            objects.setEffect(new GaussianBlur());
//            pauseMenu p=new pauseMenu(stage);
//            Stage popupStage = new Stage(StageStyle.TRANSPARENT);
//            {
//                popupStage.initOwner(stage);
//                popupStage.initModality(Modality.APPLICATION_MODAL);
//
//                popupStage.setScene(p.scene);
//                popupStage.show();
//            }
//            p.Button1.setOnMouseClicked(event -> {
//            objects.setEffect(null);
//                //animation.play();
//                popupStage.hide();
//            });
//            p.Button3.setOnMouseClicked(f -> {
//                objects.setEffect(null);
//                popupStage.hide();
//                mainPage q=new mainPage(stage);
//                stage.setScene(q.scene);
//                stage.show();
//
//            });
//
//        });
    }
    {
        //game_objects.getChildren().addAll(c.ball, b.ball,Button4);
        //game_objects_ball.getChildren().addAll(c.ball);

        scene2 = new Scene(objects, 450, 500,Color.BLACK);
//        Image image = new Image( getClass().getResource("21.gif").toExternalForm());
//        ImagePattern imagePattern = new ImagePattern(image);
//        scene2.setFill(imagePattern);
        {scene2.setOnKeyPressed(f -> {
                    switch (f.getCode()) {
                        case SPACE:
                            if(flag==1)
                            {
                                timeline6.play();
                                flag=0;
                            }


                            ball.move();
                            //clearTimeout();
                            //b.timeline.play();
                            //update();

                            break;
                        case P: {
            /*mainPage p=new mainPage(stage);
            stage.setScene(p.scene);
            stage.show();*/
                            pause();
                            ballY=objects.getChildren().get(0).getBoundsInParent().getMaxY();
                            ball=new ball(ballY);
                            objects.getChildren().set(0, ball.ball);
                            objects.setEffect(new GaussianBlur());
                            pauseMenu p = new pauseMenu(stage,this);
                            Stage popupStage = new Stage(StageStyle.TRANSPARENT);
                            {
                                popupStage.initOwner(stage);
                                popupStage.initModality(Modality.APPLICATION_MODAL);
                                popupStage.setScene(p.scene);
                                popupStage.show();
                            }
                            p.Button1.setOnMouseClicked(event -> {
                                objects.setEffect(null);
                                //animation.play();
                                popupStage.hide();
                                play();
                            });
                            p.Button3.setOnMouseClicked(g -> {
                                objects.setEffect(null);
                                popupStage.hide();
//                                        try {
//                                            //String content = "This is the content to write into fiple";
//                                            File file = new File("src/sample/saveGame.txt");
//                                            // if file doesnt exists, then create it
//                                            if (!file.exists()) {
//                                                file.createNewFile();
//                                            }
//                                            FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
//                                            BufferedWriter bw = new BufferedWriter(fw);
//                                            //bw.write(content);
//                                            bw.write("Name\n");
//                                            bw.write(12+"\n");
//                                            bw.write( ball.ball.getBoundsInParent().getMaxY()+"\n");
//                                            for (int i = 0; i < l2.size(); i++)
//                                            {
//                                                bw.write(l2.get(i).Y+"\n");
//                                                bw.write( l2.get(i).getAngle()+"\n");
//                                            }
//                                            bw.close();
//                                            System.out.println("Done");
//                                        } catch (IOException e) {
//                                            e.printStackTrace();
//                                        }
                               player.saveGame(this);
                                mainPage q = new mainPage(stage);
                                stage.setScene(q.scene);
                                stage.show();
                            });
                            break;
                        }
                    } });}
    }

   /* {
        scene2.setOnKeyPressed(f -> {
            switch (f.getCode()) {
                case SPACE:
                   //clearTimeout();
                     b.move();
                   //update();

                    break;
                case F:
                    endGamePage p= new endGamePage(stage);
                    stage.setScene(p.scene);
                    stage.show();
                    break;
            }
        });

    }*/

    /*  ObservableBooleanValue colliding = Bindings.createBooleanBinding(new Callable<Boolean>() {
        @Override
        public Boolean call() throws Exception {
            //if((b.circle.getBoundsInParent().intersects(sce)))return true;
            //else return false;
            return objects.getChildren().get(0).getBoundsInParent().intersects( objects.getChildren().get(1).getBoundsInParent());
            //return  b.circle.intersects(
            //b.circle.sceneToLocal(sq.line1.localToScene(
            //sq.line1.getBoundsInLocal())));
            //Shape intersect = Shape.intersect(b.circle, sq.line1);
            //return (intersect.getBoundsInLocal().getWidth() != -1);
        }
    }, b.circle.boundsInParentProperty(), sq.line1.boundsInParentProperty());
    {
        colliding.addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> obs,
                                Boolean oldValue, Boolean newValue) {
         //       if (newValue==true&& b.circle.getFill()!=sq.line1.getStroke()+) {
                    System.out.println("bhosde me daal le collision");
                } //else {
                  //System.out.println("Not colliding");
                  // }
                }
              });
    }*/
    Timeline timeline4 = new Timeline(

            new KeyFrame(Duration.millis(100),
                    new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                              //  if (objects.getChildren().get(0).getBoundsInParent().intersects(sq.line1.getBoundsInParent())) {
                                //    System.out.println("collided");
                                //}
                            //if (objects.getChildren().get(0).getBoundsInParent().intersects(sq.line4.getBoundsInParent())) {
                              //  System.out.println("same color collided");
                            //Node ball=objects.getChildren().get(0);
                            for(int i=0;i< l2.size();i++) {
                                //ball.ball.sceneToLocal(l2.get(i).getNode(1).localToScene(
                                  //      l2.get(i).getNode(1).getBoundsInLocal()));
                                Shape intersect = intersect( ball.ball,(Shape) l2.get(i).getNode(1));
                                Shape intersect2 = intersect(ball.ball, (Shape) l2.get(i).getNode(2));
                                Shape intersect3 = intersect(ball.ball, (Shape) l2.get(i).getNode(3));
                                Shape intersect4 = intersect( ball.ball, (Shape) l2.get(i).getNode(4));
                               // System.out.println("fdnak");
                                if(l2.get(i).switchCollected==false) {
                                    Shape intersect6 = intersect( ball.ball, (Shape) l2.get(i).getNode(6));
                                    if (intersect6.getBoundsInLocal().getWidth() != -1)
                                {

//                                       endGamePage p= new endGamePage(stage);
//                                       stage.setScene(p.scene);
//                                       stage.show();
                                    //stop();
                                    //System.out.println("jansdjks");
                                    ball.changeColor();
                                    l2.get(i).obstacle.getChildren().remove(4);
                                    l2.get(i).switchCollected=true;

                                }}
                                if(l2.get(i).starCollected==false)
                                {
                                    Shape intersect5 = intersect( ball.ball, (Shape) l2.get(i).getNode(5));
                                    if(intersect5.getBoundsInLocal().getWidth() != -1)
                                    {
                                       //System.out.println("jansdjks");
                                       //ball.changeColor();
                                        player.points=player.points+1;
                                        String x=Integer.toString(player.points);
                                        text.setText(x);
                                        //page.translate(l2.get(i).obstacle.getChildren().get(4), 10, 1, false, 0, -5) ;
                                        l2.get(i).obstacle.getChildren().remove(4);
                                        l2.get(i).starCollected=true;
                                    }
                                }
                                    if (intersect.getBoundsInLocal().getWidth() != -1 && ball.ball.getFill()!=Color.BLUE) {
//                                   endGamePage p= new endGamePage(stage);
//                                   stage.setScene(p.scene);
//                                   stage.show();
                                   stop();

                               }

                                else if (intersect2.getBoundsInLocal().getWidth() != -1 && ball.ball.getFill()!=Color.WHITE) {
//                                   endGamePage p= new endGamePage(stage);
//                                   stage.setScene(p.scene);
//                                   stage.show();
                                   stop();

                               }
                                else if (intersect4.getBoundsInLocal().getWidth() != -1&& ball.ball.getFill()!=Color.YELLOW){
//                                   endGamePage p= new endGamePage(stage);
//                                   stage.setScene(p.scene);
//                                   stage.show();
                                   stop();

                               }
                               else if (intersect3.getBoundsInLocal().getWidth() != -1&&ball.ball.getFill()!=Color.RED)
                               {

//                                       endGamePage p= new endGamePage(stage);
//                                       stage.setScene(p.scene);
//                                       stage.show();
                                   stop();
                               }
                             //  else if (intersect5.getBoundsInLocal().getWidth() != -1)
                               {

//                                       endGamePage p= new endGamePage(stage);
//                                       stage.setScene(p.scene);
//                                       stage.show();
                                  // stop();
                                   //ball.changeColor((Color)ball.ball.getFill());
                               }


                            }
                            }
                            },

                    new javafx.animation.KeyValue[]{}));
    {
        timeline4.setCycleCount(Timeline.INDEFINITE);
       timeline4.play();
    }
    {timeline6 = new Timeline(

            new KeyFrame(Duration.millis(25),
                    new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            //Node ball=objects.getChildren().get(0);

                            if(500-ball.ball.getBoundsInParent().getMaxY()>200)
                            { double x=2;
                               // double x=500-ball.ball.getBoundsInParent().getMaxY()-300;
                                //if(500-ball.ball.getBoundsInParent().getMaxY()>400)  x=8;
                                 //x=500-ball.ball.getBoundsInParent().getMaxY()>300;

                                // objects.getChildren().get(0).setLayoutY(-x);
                                for(int i=0;i<l2.size();i++)
                                {
                                    //double k= objects.getChildren().get(i).getLayoutY();
                                    //objects.getChildren().get(i).setLayoutY(k+x);
                                    l2.get(i).Y= l2.get(i).Y+x;
                                    //c.Y=c.Y+x;
                                    l2.get(i).update();
                                    l2.get(i).setCentre((int)l2.get(i).Y);
                                    //c.y=c.Y;
                                    l2.get(i).y=l2.get(i).Y;

//                                  if(i==1)
//                                    {
//                                        c.Y=c.Y+x;
//                                        c.update();
//                                        c.setCentre((int)c.Y);
//                                        c.y=c.Y;
//                                        System.out.println(c.Y+" "+c.y);
//                                    }
//                                    if(i==2)
//                                    {
//                                        sq.Y=sq.Y+x;
//                                        sq.update();
//                                        sq.setCentre((int)sq.Y);
//                                        sq.y=sq.Y;
//                                        System.out.println(sq.Y+" "+ sq.y);
//                                    }

                                }
                            }if(ball.ball.getBoundsInParent().getMaxY()>500){
                                timeline6.stop();
                            endGamePage p= new endGamePage(stage,player);
                            stage.setScene(p.scene);
                            stage.show();

                            }

                        }
                    }
            ));}
    {
        timeline6.setCycleCount(Timeline.INDEFINITE);
        timeline6.play();
    }
    Timeline timeline5 = new Timeline(

            new KeyFrame(Duration.millis(200),
                    new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            if(l2.get(0).obstacle.getBoundsInParent().getMinY()>500)
                            {
                                Random r = new Random();
                                int result = r.nextInt(5-0) + 0;
                                if(time>1000) {
                                    time = time - 20;
                                }
                                     if(result==0)l2.add(new circle(l2.get(l2.size()-1).Y-400,time));
                                else if(result==1)l2.add(new square(l2.get(l2.size()-1).Y-400,time));
                                else if(result==2)l2.add(new cross(l2.get(l2.size()-1).Y-400,time));
                                else if(result==3)l2.add(new double_cross(l2.get(l2.size()-1).Y-400,time));
                                else if(result==4)l2.add(new double_circle(l2.get(l2.size()-1).Y-400,time));
                                l2.remove(0);
                                objects.getChildren().remove(2);
                                objects.getChildren().add(l2.get(l2.size()-1).obstacle);
                                //objects.setCache(true);
                                //objects.setCacheShape(true);
                                //setCacheHint(CacheHint.SPEED);
                                //objects.getChildren().get(objects.getChildren().size()-1).setLayoutY(Y);
                                //System.out.println(Y);
                               // System.out.println(l2.size());
                                //System.out.println(l2.get(l2.size()-1).Y);
                            }
                        }
                    }
            ));
    {
        timeline5.setCycleCount(Timeline.INDEFINITE);
        timeline5.play();
    }

    public void stop()
    {
        endGamePage p= new endGamePage(stage,player);
        stage.setScene(p.scene);
        stage.show();
        timeline4.stop();
        timeline5.stop();
        timeline6.stop();
        for(int i=0;i<l2.size();i++)
        {
            l2.get(i).stop();
        }
    }
    public void pause()
    {
        timeline4.stop();
        timeline5.stop();
        timeline6.stop();
        flag=1;
        //b.timeline.stop();
        for(int i=0;i<l2.size();i++)
        {
            l2.get(i).stop();
        }
    }
    public void play()
    {
        timeline4.play();
        timeline5.play();
        //timeline6.play();
        //b.timeline.stop();
        for(int i=0;i<l2.size();i++)
        {
            l2.get(i).play();
        }
    }
    /*Timeline timeline5 = new Timeline(
            new KeyFrame(Duration.millis(100),
                    new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent event) {
                            if (b.circle.getBoundsInParent().getCenterY()) {
                                System.out.println("collided");
                            }
                        }
                        //}
                    }
            ));
    {
        timeline4.setCycleCount(Timeline.INDEFINITE);
        //timeline4.setCycleCount(1);
        timeline4.play();
        //Main.allTimelines.add(timeline4)}
    }*/

}

/*package app;
        import javafx.animation.KeyFrame;
        import javafx.animation.Timeline;
        import javafx.event.ActionEvent;
        import javafx.event.EventHandler;
        import javafx.geometry.Bounds;
        import javafx.scene.canvas.Canvas;
        import javafx.scene.image.Image;
        import javafx.scene.image.ImageView;
        import javafx.scene.layout.Pane;
        import javafx.scene.paint.Color;
        import javafx.util.Duration;

public class Physics {
	private static final double GRAVITY = 0.01;
	private static double v= 0;

	public boolean stopped = false;

	Ball b = MainPageController.current.currBall;
	public Physics() {
		if(!stopped) {
			Timeline fiveSecondsWonder = new Timeline(
					//Duration.
					new KeyFrame(Duration.millis(1),
							new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							fall();
							//refresh();
							//System.out.println("this is called every 5 seconds on UI thread");
						}
					}));
			fiveSecondsWonder.setCycleCount(Timeline.INDEFINITE);
			fiveSecondsWonder.play();
		}
	}

	public void fall() {
		if(!stopped) {
			if(b.y<400) {
				b.y+=v/50;

				v+=GRAVITY;
			}
		}
	}

	public void jump() {
		if(!stopped) {
			v= 0;
			Timeline fiveSecondsWonder = new Timeline(
					//Duration.
					new KeyFrame(Duration.millis(1),
							new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							up();
							//fall();
							//refresh();
							//System.out.println("this is called every 5 seconds on UI thread");
						}
					}));
			fiveSecondsWonder.setCycleCount(200);
			fiveSecondsWonder.play();
			//v=0;
		}
	}

	public void up() {
		if(!stopped)
		{
			if(b.y<400) {
				v-=5*GRAVITY;
				b.y+=v/50;
				//v-=GRAVITY;
			}

		}
	}


	public void draw(Canvas canvas) {

		Image i  = new Image(b.getPath(), 30, 30, false, false);
		canvas.getGraphicsContext2D().drawImage(i, b.x, b.y);
		canvas.getGraphicsContext2D().drawImage(i, 0, 0);

	}

	public void jump(int i, int j) {


	}
}
*/
//public class Physics {



  /*  public void draw(Pane canvas) {

        canvas.getChildren().get(0).setLayoutY(b.y);
        ((ImageView)canvas.getChildren().get(0)).setImage(new Image(b.getPath(),30,30,false,false));

    }

}*/