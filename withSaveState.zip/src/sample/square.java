package sample;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.Serializable;

public class square extends obstacles implements Serializable {
    final private int id =2;
    Line node1 = new Line();
    {
        node1.setStartX(155.0f);
        node1.setStartY(Y+80);
        node1.setEndX(305.0f);
        node1.setEndY(Y+80);
        node1.setStroke(Color.BLUE);
        node1.setStrokeWidth(10);
    }
    Line node2 = new Line();
    {
        node2.setStartX(305.0f);
        node2.setStartY(Y-80);
        node2.setEndX(305.0f);
        node2.setEndY(Y+70);
        node2.setStroke(Color.WHITE);
        node2.setStrokeWidth(10);
        //movePivot(node2, 55, 5);
        //rotateNode(node2,225,90);
    }
    Line node3 = new Line();
    {
        node3.setStartX(145.0f);
        node3.setStartY(Y-70);
        node3.setEndX(145.0f);
        node3.setEndY(Y+80);
        node3.setStroke(Color.RED);
        node3.setStrokeWidth(10);
        // movePivot(node3, -55, -5);
        // rotateNode(node3,225,90);
    }
    Line node4 = new Line();
    {
        node4.setStartX(145.0f);
        node4.setStartY(Y-80);
        node4.setEndX(295.0f);
        node4.setEndY(Y-80);
        node4.setStroke(Color.YELLOW);
        node4.setStrokeWidth(10);
        //movePivot(node4, -5, 55);
        //rotateNode(node4,225,90);
    }
    Rectangle node5 = new Rectangle();
    {
        node5.setX(205);

        node5.setHeight(40);
        node5.setWidth(40);
        node5.setY(Y-20);
        // obstacle.getChildren().add(node5);
        BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("18.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("20.jpg").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node5.setFill(imagePattern);
    }
    Rectangle node6 = new Rectangle();
    {
        node6.setX(210);

        node6.setHeight(30);
        node6.setWidth(30);
        node6.setY(Y-165);
        // obstacle.getChildren().add(node6);
        //BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("18.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        //Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("19.png").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node6.setFill(imagePattern);
    }
    /*{
        ball.getChildren().add(arc1);
        ball.getChildren().add(arc2);
        ball.getChildren().add(arc3);
        ball.getChildren().add(arc4);

    }*/
     /* private void movePivot(Node node, double x, double y){
            node.getTransforms().add(new Translate(-x,-y));
            node.setTranslateX(x); node.setTranslateY(y);

      }*/
    /*RotateTransition rtl1 = new RotateTransition(Duration.millis(2400));
     {
         rtl1.setByAngle(360);
         rtl1.setCycleCount(1);
         rtl1.setInterpolator(Interpolator.LINEAR);
         rtl1.setAutoReverse(false);
         rtl1.setNode(node);
        // rtl1.play();
     }
     Timenode animation = new Timenode(
             new KeyFrame(Duration.ZERO,evt -> {
                 rtl1.play();
             }),
             new KeyFrame(Duration.millis(1), evt -> {
                 rtl1.play();
             })
     );
     {
         animation.setCycleCount(Animation.INDEFINITE);
         animation.play();
     }*/

    Timeline timeline;
    Timeline timeline4;
    Timeline timeline2;
    Timeline timeline3;
    Rotate rotate = new Rotate(0);
    {
        node1.getTransforms().add(rotate);
        timeline = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.setAutoReverse(false);
        timeline.play();

        node4.getTransforms().add(rotate);
        timeline4 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));
        timeline4.setCycleCount(Animation.INDEFINITE);
        timeline4.setAutoReverse(false);
        timeline4.play();

        node2.getTransforms().add(rotate);
        timeline2 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));
        timeline2.setCycleCount(Animation.INDEFINITE);
        timeline2.setAutoReverse(false);
        timeline2.play();

        node3.getTransforms().add(rotate);
        timeline3 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline3.setCycleCount(Animation.INDEFINITE);
        timeline3.setAutoReverse(false);
        timeline3.play();
    }

    {
        obstacle.getChildren().add(node1);
        obstacle.getChildren().add(node2);
        obstacle.getChildren().add(node3);
        obstacle.getChildren().add(node4);
        obstacle.getChildren().add(node5);
        obstacle.getChildren().add(node6);
    }
    public square(double Y_axis,int t)
    {
        super(Y_axis,t);
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(225);

        //Line node1 ;
        {

            // rotateNode(node1,225,90);
            //movePivot(node1, 5, -55);
        }
        // Line node2;


        // Line node3;

        //  Line node4 ;



    }
    @Override
    double getAngle(int i)
    {
        return rotate.getAngle();
    }
    public square(double Y_axis,int t,double angle,boolean star,boolean Switch) {
        super(Y_axis,t);
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(225);
        rotate.setAngle(angle);
        if(Switch==true)
        {
            obstacle.getChildren().remove(5, 6);
        }

        if(star==true)
        {
            obstacle.getChildren().remove(4, 5);
        }

    }
    @Override
    void setCentre(int Y)
    {
//        node1.setCenterY(Y);
//        node2.setCenterY(Y);
//        node3.setCenterY(Y);
//        node4.setCenterY(Y);
        node1.setStartY(Y+80);
        node1.setEndY(Y+80);
        node2.setStartY(Y-80);
        node2.setEndY(Y+70);
        node3.setStartY(Y-70);
        node3.setEndY(Y+80);
        node4.setStartY(Y-80);
        node4.setEndY(Y-80);
        node5.setY(Y-20);
        node6.setY(Y-165);
        rotate.setPivotY(Y);
        // rotatenode(Y);

    }
    @Override
    Node getNode(int i)
    {
        if (i==1)return node1;
        else   if (i==2)return node2;
        else   if (i==3)return node3;
        else   if (i==4)return node4;
        else   if (i==5)return node5;
        else   if (i==6)return node6;
        return null;
    }
//    @Override
    void stop()
    {
        timeline.stop();
        timeline2.stop();
        timeline3.stop();
        timeline4.stop();
    }
    @Override
    void play()
    {
        timeline.play();
        timeline2.play();
        timeline3.play();
        timeline4.play();
    }
}
