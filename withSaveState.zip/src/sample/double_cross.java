package sample;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Point3D;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.Serializable;

public class double_cross extends obstacles implements Serializable {
    final private int id =3;
    Line node1 = new Line();
    {
        node1.setStartX(305.0f);
        node1.setStartY(Y+78);
        node1.setEndX(305.0f);
        node1.setEndY(Y);
        node1.setStroke(Color.BLUE);
        node1.setStrokeWidth(10);
    }
    Line node2 = new Line();
    {
        node2.setStartX(305.0f);
        node2.setStartY(Y-78);
        node2.setEndX(305.0f);
        node2.setEndY(Y);
        node2.setStroke(Color.WHITE);
        node2.setStrokeWidth(10);
        //movePivot(node2, 55, 5);
        //rotateNode(node2,225,90);
    }
    Line node3 = new Line();
    {
        node3.setStartX(227.0f);
        node3.setStartY(Y);
        node3.setEndX(305.0f);
        node3.setEndY(Y);
        node3.setStroke(Color.RED);
        node3.setStrokeWidth(10);
        // movePivot(node3, -55, -5);
        // rotateNode(node3,225,90);
    }
    Line node4 = new Line();
    {
        node4.setStartX(305.0f);
        node4.setStartY(Y);
        node4.setEndX(383.0f);
        node4.setEndY(Y);
        node4.setStroke(Color.YELLOW);
        node4.setStrokeWidth(10);
        //movePivot(node4, -5, 55);
        //rotateNode(node4,225,90);
    }
    Line node7 = new Line();
    {
        node7.setStartX(145.0f);
        node7.setStartY(Y+78);
        node7.setEndX(145.0f);
        node7.setEndY(Y);
        node7.setStroke(Color.BLUE);
        node7.setStrokeWidth(10);
    }
    Line node8 = new Line();
    {
        node8.setStartX(145.0f);
        node8.setStartY(Y-78);
        node8.setEndX(145.0f);
        node8.setEndY(Y);
        node8.setStroke(Color.WHITE);
        node8.setStrokeWidth(10);
        //movePivot(node2, 55, 5);
        //rotateNode(node2,225,90);
    }
    Line node9 = new Line();
    {
        node9.setStartX(67.0f);
        node9.setStartY(Y);
        node9.setEndX(145.0f);
        node9.setEndY(Y);
        node9.setStroke(Color.YELLOW);
        node9.setStrokeWidth(10);
        // movePivot(node3, -55, -5);
        // rotateNode(node3,225,90);
    }
    Line node10 = new Line();
    {
        node10.setStartX(145.0f);
        node10.setStartY(Y);
        node10.setEndX(223.0f);
        node10.setEndY(Y);
        node10.setStroke(Color.RED);
        node10.setStrokeWidth(10);
        //movePivot(node4, -5, 55);
        //rotateNode(node4,225,90);
    }
    Rectangle node5 = new Rectangle();
    {
        node5.setX(205);

        node5.setHeight(40);
        node5.setWidth(40);
        node5.setY(Y-100);
        // obstacle.getChildren().add(node5);
        BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("18.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("20.jpg").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node5.setFill(imagePattern);
    }
    Rectangle node6 = new Rectangle();
    {
        node6.setX(210);

        node6.setHeight(30);
        node6.setWidth(30);
        node6.setY(Y-165);
        // obstacle.getChildren().add(node6);
        //BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("18.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        //Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("19.png").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node6.setFill(imagePattern);
    }

    /*{
        ball.getChildren().add(arc1);
        ball.getChildren().add(arc2);
        ball.getChildren().add(arc3);
        ball.getChildren().add(arc4);

    }*/
     /* private void movePivot(Node node, double x, double y){
            node.getTransforms().add(new Translate(-x,-y));
            node.setTranslateX(x); node.setTranslateY(y);

      }*/
    /*RotateTransition rtl1 = new RotateTransition(Duration.millis(2400));
     {
         rtl1.setByAngle(360);
         rtl1.setCycleCount(1);
         rtl1.setInterpolator(Interpolator.LINEAR);
         rtl1.setAutoReverse(false);
         rtl1.setNode(node);
        // rtl1.play();
     }
     Timenode animation = new Timenode(
             new KeyFrame(Duration.ZERO,evt -> {
                 rtl1.play();
             }),
             new KeyFrame(Duration.millis(1), evt -> {
                 rtl1.play();
             })
     );
     {
         animation.setCycleCount(Animation.INDEFINITE);
         animation.play();
     }*/


    Rotate rotate = new Rotate(0);
    Rotate rotate1 = new Rotate(0);
    //Rotate rotate1= new Rotate(0);
    {
        //rotate1.setAxis(new Point3D(0, 0, 1));
        rotate1.setAxis(new Point3D(0, 0, -1));}
    Timeline timeline;
    Timeline timeline4;
    Timeline timeline2;
    Timeline timeline3;
    Timeline timeline7;
    Timeline timeline8;
    Timeline timeline9;
    Timeline timeline10;
    {
        node1.getTransforms().add(rotate);

        timeline = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.setAutoReverse(false);

        timeline.play();
        node4.getTransforms().add(rotate);

        timeline4 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline4.setCycleCount(Animation.INDEFINITE);
        timeline4.setAutoReverse(false);

        timeline4.play();
        node2.getTransforms().add(rotate);

        timeline2 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline2.setCycleCount(Animation.INDEFINITE);
        timeline2.setAutoReverse(false);

        timeline2.play();
        node3.getTransforms().add(rotate);

        timeline3 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline3.setCycleCount(Animation.INDEFINITE);
        timeline3.setAutoReverse(false);

        timeline3.play();
        node7.getTransforms().add(rotate1);
        timeline7 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate1.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate1.angleProperty(), 360d)));

        timeline7.setCycleCount(Animation.INDEFINITE);
        timeline7.setAutoReverse(false);
        timeline7.play();

        node8.getTransforms().add(rotate1);
        timeline8 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate1.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate1.angleProperty(), 360d)));

        timeline8.setCycleCount(Animation.INDEFINITE);
        timeline8.setAutoReverse(false);
        timeline8.play();

        node9.getTransforms().add(rotate1);
        timeline9 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate1.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate1.angleProperty(), 360d)));
        timeline9.setCycleCount(Animation.INDEFINITE);
        timeline9.setAutoReverse(false);
        timeline9.play();

        node10.getTransforms().add(rotate1);
        timeline10 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate1.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate1.angleProperty(), 360d)));
        timeline10.setCycleCount(Animation.INDEFINITE);
        timeline10.setAutoReverse(false);
        timeline10.play();
    }
    {
        obstacle.getChildren().add(node1);
        obstacle.getChildren().add(node2);
        obstacle.getChildren().add(node3);
        obstacle.getChildren().add(node4);
        obstacle.getChildren().add(node5);
        obstacle.getChildren().add(node6);
        obstacle.getChildren().add(node7);
        obstacle.getChildren().add(node8);
        obstacle.getChildren().add(node9);
        obstacle.getChildren().add(node10);
    }
    public double_cross(double Y_axis,int t)
    {
        super(Y_axis,t);
        //Y=Y_axis;
        //y=Y_axis;
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(305);
        rotate1.setPivotY(Y_axis);
        rotate1.setPivotX(145);
        //Line node1 ;
        {
            // rotateNode(node1,225,90);
            //movePivot(node1, 5, -55);
        }
        // Line node2;
        // Line node3;
        //  Line node4 ;
    }
    public double_cross(double Y_axis,int t,double angle1,double angle2,boolean star,boolean Switch) {
        super(Y_axis, t);
        //Y=Y_axis;
        //y=Y_axis;
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(305);
        rotate1.setPivotY(Y_axis);
        rotate1.setPivotX(145);
        rotate.setAngle(angle1);
        rotate1.setAngle(angle2);
        if(Switch==true)
        {
            obstacle.getChildren().remove(5, 6);
        }

        if(star==true)
        {
            obstacle.getChildren().remove(4, 5);
        }
    }
    @Override
    double getAngle(int i)
    {
        if(i==1)return rotate.getAngle();
        else if(i==2)return rotate1.getAngle();
        return Double.parseDouble(null);
    }

    @Override
    void setCentre(int Y)
    {
//        node1.setCenterY(Y);
//        node2.setCenterY(Y);
//        node3.setCenterY(Y);
//        node4.setCenterY(Y);
        node1.setStartY(Y+80);
        node1.setEndY(Y);
        node2.setStartY(Y-80);
        node2.setEndY(Y);
        node3.setStartY(Y);
        node3.setEndY(Y);
        node4.setStartY(Y);
        node4.setEndY(Y);
        node5.setY(Y-100);
        node6.setY(Y-165);
        node7.setStartY(Y+80);
        node7.setEndY(Y);
        node8.setStartY(Y-80);
        node8.setEndY(Y);
        node9.setStartY(Y);
        node9.setEndY(Y);
        node10.setStartY(Y);
        node10.setEndY(Y);
        rotate.setPivotY(Y);
        rotate1.setPivotY(Y);
        // rotatenode(Y);

    }
    @Override
    Node getNode(int i)
    {
        if (i==1)return node1;
        else   if (i==2)return node2;
        else   if (i==3)return node3;
        else   if (i==4)return node4;
        else   if (i==5)return node5;
        else   if (i==6)return node6;
        return null;
    }
    @Override
    void stop()
    {
        timeline.stop();
        timeline2.stop();
        timeline3.stop();
        timeline4.stop();
        timeline7.stop();
        timeline8.stop();
        timeline9.stop();
        timeline10.stop();
    }
    @Override
    void play()
    {
        timeline.play();
        timeline2.play();
        timeline3.play();
        timeline4.play();
        timeline7.play();
        timeline8.play();
        timeline9.play();
        timeline10.play();
    }
}
