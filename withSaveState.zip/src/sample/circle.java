package sample;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.*;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.Serializable;
import java.util.HashMap;

public class circle extends obstacles implements Serializable {
    private final int id = 1;
    HashMap<Arc,Color> map=new HashMap<Arc,Color>();
   // { Y=290;
    // y=290;}
    // star= new Star(Y, 0);
   Arc node1 = new Arc();


    {   node1.setCenterX(225.0f);
        node1.setCenterY(Y);
        node1.setRadiusX(80.0f);
        node1.setRadiusY(80.0f);
        node1.setStartAngle(45.0f);
        node1.setLength(90.0f);
        node1.setStroke(Color.BLUE);
        node1.setStrokeWidth(8);
        node1.setFill(Color.TRANSPARENT);
        node1.setType(ArcType.OPEN);
        //animate(node2);
        //map.put(node2, Color.WHITE);

        //movePivot(node2, 50.0f, 0.0f);
    }

    Arc node2 = new Arc();

    {   node2.setCenterX(225.0f);
        node2.setCenterY(Y);
        node2.setRadiusX(80.0f);
        node2.setRadiusY(80.0f);
        node2.setStartAngle(135.0f);
        node2.setLength(90.0f);
        node2.setStroke(Color.WHITE);
        node2.setStrokeWidth(8);
        node2.setFill(Color.TRANSPARENT);
        node2.setType(ArcType.OPEN);
        //animate(node2);
        //map.put(node2, Color.WHITE);

        //movePivot(node2, 50.0f, 0.0f);
    }
    Arc node3 = new Arc();
    {
        node3.setCenterX(225.0f);
        node3.setCenterY(Y);
        node3.setRadiusX(80.0f);
        node3.setRadiusY(80.0f);
        node3.setStartAngle(225.0f);
        node3.setLength(90.0f);
        node3.setStroke(Color.RED);
        node3.setStrokeWidth(8);
        node3.setFill(Color.TRANSPARENT);
        node3.setType(ArcType.OPEN);
        //animate(node3);
        //map.put(node3, Color.RED);

        // movePivot(node3, 0.0f, -50.0f);
    }
    Arc node4 = new Arc();
    {
        node4.setCenterX(225.0f);
        node4.setCenterY(Y);
        node4.setRadiusX(80.0f);
        node4.setRadiusY(80.0f);
        node4.setStartAngle(315.0f);
        node4.setLength(90.0f);
        node4.setStroke(Color.YELLOW);
        node4.setStrokeWidth(8);
        node4.setFill(Color.TRANSPARENT);
        node4.setType(ArcType.OPEN);
        // movePivot(node4, -50.0f, 0.0f);
       //animate(node4);
        //map.put(node4, Color.YELLOW);
     //   System.out.println(node4.getBoundsInLocal());
    }
    Rectangle node5 = new Rectangle();
    {
        node5.setX(205);

        node5.setHeight(40);
        node5.setWidth(40);
        node5.setY(Y-20);
       // obstacle.getChildren().add(node5);
        BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("18.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("18.jpg").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node5.setFill(imagePattern);
    }
    Rectangle node6 = new Rectangle();
    {
        node6.setX(210);

        node6.setHeight(30);
        node6.setWidth(30);
        node6.setY(Y-165);
        // obstacle.getChildren().add(node6);
        //BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("19.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        //Background background2 = new Background(backgroundImage1);
        Image image = new Image( getClass().getResource("19.png").toExternalForm());
        ImagePattern imagePattern = new ImagePattern(image);
        node6.setFill(imagePattern);
    }
//


//    Timeline timeline6 = new Timeline(
//
//            new KeyFrame(Duration.millis(200),
//                    new EventHandler<ActionEvent>() {
//                        @Override
//                        public void handle(ActionEvent event) {
//                            if(arc1.getCenterY()!=Y) {
//                                Y=arc1.getCenterY();
//                                rotatearc((int) arc1.getCenterY());
//                                setCentre((int)arc1.getCenterY());
//
//                            }
//                        }
//                    }
//            ));
//    {
//        timeline6.setCycleCount(Timeline.INDEFINITE);
//        timeline6.play();
//    }
    //  private void movePivot(Node node, double x, double y){
    //    node.getTransforms().add(new Translate(-x,-y));
  //      node.setTranslateX(x); node.setTranslateY(y);
//}


   /* Timeline animation1 = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(arc1.startAngleProperty(), arc1.getStartAngle(), Interpolator.LINEAR)),
            new KeyFrame(Duration.seconds(2), new KeyValue(arc1.startAngleProperty(), arc1.getStartAngle() - 360, Interpolator.LINEAR))
    );
    {
        animation1.setCycleCount(Animation.INDEFINITE);
        animation1.play();}
    Timeline animation2 = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(arc2.startAngleProperty(), arc2.getStartAngle(), Interpolator.LINEAR)),
            new KeyFrame(Duration.seconds(2), new KeyValue(arc2.startAngleProperty(), arc2.getStartAngle() - 360, Interpolator.LINEAR))
    );
    {
        animation2.setCycleCount(Animation.INDEFINITE);
        animation2.play();}
    Timeline animation3 = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(arc3.startAngleProperty(), arc3.getStartAngle(), Interpolator.LINEAR)),
            new KeyFrame(Duration.seconds(2), new KeyValue(arc3.startAngleProperty(), arc3.getStartAngle() - 360, Interpolator.LINEAR))
    );
    {
        animation3.setCycleCount(Animation.INDEFINITE);
        animation3.play();}
    Timeline animation4 = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(arc4.startAngleProperty(), arc4.getStartAngle(), Interpolator.LINEAR)),
            new KeyFrame(Duration.seconds(2), new KeyValue(arc4.startAngleProperty(), arc4.getStartAngle() - 360, Interpolator.LINEAR))
    );
    {
        animation4.setCycleCount(Animation.INDEFINITE);
        animation4.play();}*/
    //Group ball = new Group();
    {
        obstacle.getChildren().add(node1);
        obstacle.getChildren().add(node2);
        obstacle.getChildren().add(node3);
        obstacle.getChildren().add(node4);
        obstacle.getChildren().add(node5);
        obstacle.getChildren().add(node6);

    }

    Rotate rotate = new Rotate(0);
    Timeline timeline;
    Timeline timeline4;
    Timeline timeline2;
    Timeline timeline3;
    {


        node1.getTransforms().add(rotate);

         timeline = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.setAutoReverse(false);

        timeline.play();
        node4.getTransforms().add(rotate);

        timeline4 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline4.setCycleCount(Animation.INDEFINITE);
        timeline4.setAutoReverse(false);

        timeline4.play();
        node2.getTransforms().add(rotate);

         timeline2 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline2.setCycleCount(Animation.INDEFINITE);
        timeline2.setAutoReverse(false);

        timeline2.play();
        node3.getTransforms().add(rotate);

        timeline3 = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(rotate.angleProperty(), 0d)),
                new KeyFrame(Duration.millis(time), new KeyValue(rotate.angleProperty(), 360d)));

        timeline3.setCycleCount(Animation.INDEFINITE);
        timeline3.setAutoReverse(false);

        timeline3.play();
    }



    void animate (Arc arc)
    {
        Timeline animation = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(arc.startAngleProperty(), arc.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(arc.startAngleProperty(), arc.getStartAngle() - 360, Interpolator.LINEAR))
        );
        {
            animation.setCycleCount(Animation.INDEFINITE);
            animation.play();}
        }
        @Override
        void setCentre(int Y)
        {
            node1.setCenterY(Y);
            node2.setCenterY(Y);
            node3.setCenterY(Y);
            node4.setCenterY(Y);
            node5.setY(Y-20);
            node6.setY(Y-165);
            rotate.setPivotY(Y);
           // rotatenode(Y);

        }



    public circle(double Y_axis,int t) {
        super(Y_axis,t);
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(225);
//        node1 = new Arc();
//
//            ((Arc)node1).setCenterX(225.0f);
//            ((Arc)node1).setCenterY(Y);
//            ((Arc)node1).setRadiusX(60.0f);
//            ((Arc)node1).setRadiusY(60.0f);
//            ((Arc)node1).setStartAngle(45.0f);
//            ((Arc)node1).setLength(90.0f);
//            node1.setStroke(Color.BLUE);
//            node1.setStrokeWidth(10);
//            node1.setFill(Color.TRANSPARENT);
//            ((Arc) node1).setType(ArcType.OPEN);



            //animate(node1);
            //map.put(node1, Color.BLUE);

            // movePivot(arc1, 0.0f, 50.0f);

       // rotatearc(290);
    }
    public circle(double Y_axis,int t,double angle,boolean star,boolean Switch) {
        super(Y_axis, t);
        rotate.setPivotY(Y_axis);
        rotate.setPivotX(225);
        rotate.setAngle(angle);
        if(Switch==true)
        {
            obstacle.getChildren().remove(5, 6);
        }

        if(star==true)
        {
            obstacle.getChildren().remove(4, 5);
        }
    }
    @Override
    double getAngle(int i)
    {
        return rotate.getAngle();
    }
    @Override
    Node getNode(int i)
    {
        if (i==1)return node1;
        else   if (i==2)return node2;
        else   if (i==3)return node3;
        else   if (i==4)return node4;
        else   if (i==5)return node5;
        else   if (i==6)return node6;

        return null;
    }
    @Override
    void stop()
    {
        timeline.stop();
        timeline2.stop();
        timeline3.stop();
        timeline4.stop();
    }
    @Override
    void play()
    {
        timeline.play();
        timeline2.play();
        timeline3.play();
        timeline4.play();
    }
//    public void update(double x) {
//
//    }
}
