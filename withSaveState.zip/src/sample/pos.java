package sample;
public class pos {
    private float x;
    private float y;
    public pos(float x,float y)
    {
        x=this.x;
        y=this.y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }
}
