package sample;

import javafx.animation.*;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Random;

public class ball implements Serializable {
   // pos p = new pos(200.0f, 450.0f);
    Color colour = Color.RED;

    Circle ball = new Circle( 8.f);
    {ball.setCenterX(225);
        ball.setFill(colour);}
    //circle c;
//square y;
    {

        // circle.setOnKeyPressed(f -> {
        //           switch (f.getCode()) {
        //             case SPACE:
        //               move();
        //             break;
        //   }});
    }
public void saveObject(ObjectOutputStream oos) throws IOException {
    oos.writeObject(this);
}


    Group obstacle = new Group(ball);

    public ball(double Y ) {
ball.setCenterY(Y);
    }

    public Color getColour() {
        return colour;
    }

    public void changeColor() {
        Color colour[] = new Color[]{Color.RED, Color.BLUE, Color.YELLOW, Color.WHITE};
        Random r = new Random();

        int result = r.nextInt(4-0) + 0;
        while(colour[result]==this.colour)
        {
            result = r.nextInt(4-0) + 0;
        }
        this.colour=colour[result];
        ball.setFill(colour[result]);
    }

    public void collide() {

    }

    public void burst() {
    }

    public void move() {

        page.translate(ball, 160, 1, false, 0, -40);
        /*for(int i=0;i<10;i++)
        {
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                       //page.translate(circle, 2000, 1, false, 0, 600);
                       // System.out.println(circle.getBoundsInParent().getMinY()+" "+circle.getBoundsInParent().getMaxY());
                       //System.out.println("ball"+circle.getBoundsInParent());
                       // System.out.println("arc"+y.line1.getBoundsInParent());
                       //if((y.line1.getBoundsInParent().getMaxY()-circle.getBoundsInParent().getMaxY())/(y.line1.getBoundsInParent().getMaxX()-circle.getBoundsInParent().getMaxX())==(y.line1.getBoundsInParent().getMaxY()-y.line1.getBoundsInParent().getMinY())/(y.line1.getBoundsInParent().getMaxX()-y.line1.getBoundsInParent().getMinX()))
                       //{
                       //  System.out.println("Collision");
                       //System.out.println(y.line1.getBoundsInParent());
                       //System.out.println(circle.getBoundsInParent());
                       //}
                       //if(c.arc1.getBoundsInParent().getMinX()<=217&&c.arc1.getBoundsInParent().getMaxX()>=233&&.)

                    }
                }, 20);}*/
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        page.translate(ball, 2400, 1, false, 0, 600);
                        // for(int i=0;i<20;i++){
                        //            {
                        //            if(circle.getBoundsInParent().getMaxY()>500)System.out.println("GameOver");
                        //          }
                        //}
                    }
                }, 160
        );
    }}

//Timeline timeline1= new Timeline(
//
//        new KeyFrame(Duration.millis(),
//                new EventHandler<ActionEvent>() {
//                    @Override
//                    public void handle(ActionEvent event) {
//                        page.translate(circle, 160, 1, false, 0, -40);
//                        new java.util.Timer().schedule(
//                new java.util.TimerTask() {
//                    @Override
//                    public void run() {
//                        page.translate(circle, 2400, 1, false, 0, 600);
//                        // for(int i=0;i<20;i++){
//                        //            {
//                        //            if(circle.getBoundsInParent().getMaxY()>500)System.out.println("GameOver");
//                        //          }
//                        //}
//                    }
//                }, 160
//
//        );
//                    }
//                }
//        ));
//    {
//       timeline1.setCycleCount(1);
//        //timeline1.play();
//    }




        //  Timeline timeline = new Timeline(new KeyFrame(Duration.ZERO, new KeyValue(circle.centerYProperty(),circle.getCenterY(), Interpolator.LINEAR)),//        new KeyFrame(Duration.millis(1), new KeyValue(circle.centerYProperty(),circle.getCenterY()-60, Interpolator.LINEAR)),
        //       new KeyFrame(Duration.seconds(4), new KeyValue(circle.centerYProperty(),circle.getCenterY()+400, Interpolator.LINEAR)));
        // Timeline timeline = new Timeline(new KeyFrame(Duration.ZERO, evt -> {
        //   page.translate(circle, 300, 1, false, 0, -100);
        //}),
        //               new KeyFrame(Duration.millis(300), evt -> {
        //                 page.translate(circle, 1200, 1, false, 0, 400);
             //            }),
        //new KeyFrame(Duration.millis(1500), evt -> {
          //  page.translate(circle, 1200, 1, false, 0, 400);
        //}));

        //timeline.setCycleCount(Animation.INDEFINITE);
        //timeline.setAutoReverse(false);

        //timeline.play();

       
          /*  TranslateTransition translate = new TranslateTransition();
            {
                translate.setDuration(Duration.millis(200));
                translate.setCycleCount(2);
                translate.setAutoReverse(true);
                translate.setNode(circle);
            }
            translate.setByY(-40);
            translate.play();*/
         // private static final double GRAVITY = 0.01;
         //   private static double v= 0;

    //public boolean stopped = false;

    //Ball b = MainPageController.current.currBall;



           





    // graphics context





