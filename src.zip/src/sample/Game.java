package sample;

public class Game {
}
