package sample;

import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

class Switch extends gameObjects {
    float size;
    Circle Switch = new Circle( 10.f);
    {
        Switch.setCenterX(225);
        Switch.setFill(Color.YELLOW);
       // Switch.setFill(Color.YELLOW)
    }
    {obstacle.getChildren().add(Switch);}
    public Switch(double y_axis, int t) {
        super(y_axis);
        Switch.setCenterY(y_axis);
    }

    void getSize() {

    }

    void action() {

    }


    @Override
    void update() {
        page.translate(Switch,(int)(Y-y)*3,1, false, 0, (int)(Y-y));
    }

    @Override
    void setCentre(int Y) {
        Switch.setCenterY(Y);
    }

    @Override
    Node getNode(int y) {
        return Switch;
    }

    @Override
    void stop() {

    }

    @Override
    void play() {

    }
}