package sample;


public class Player
{
    String Name;
    int points;
    int starCollected;
    Player(String Name)
    {

    }
    void update()
    {

    }
    void pauseGame()
    {

    }
    void saveGame()
    {

    }
    void restartGame()
    {

    }
    void exitGame()
    {

    }
    void gameEnds()
    {

    }
    void getName()
    {

    }
    void getPoints()
    {

    }
    void getStarCollected()
    {

    }
}
