package sample;


import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.concurrent.Task;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
public class ball {

    Color colour = Color.RED;
    pos p = new pos(220.0f, 400.0f);
    Circle circle = new Circle(200.0f, 400.0f, 8.f);

    {
        circle.setFill(colour);
    }



    Group ball = new Group(circle);

    public ball() {
    }

    public Color getColour() {
        return colour;
    }

    public void changeColor() {
        Color colour[] = new Color[]{Color.RED, Color.ORANGE, Color.YELLOW, Color.WHITE};
    }

    public void collide() {
    }

    public void burst() {
    }

    public void move() {



            TranslateTransition translate = new TranslateTransition();
            {
                translate.setDuration(Duration.millis(200));
                translate.setCycleCount(2);
                translate.setAutoReverse(true);
                translate.setNode(circle);
            }
            translate.setByY(-40);
            translate.play();
           
    }

    }


    // graphics context





