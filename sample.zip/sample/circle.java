package sample;

import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.transform.Translate;
import javafx.util.Duration;

public class circle {

    Arc  arc1= new Arc();
    {
        arc1.setCenterX(200.0f);
        arc1.setCenterY(200.0f);
        arc1.setRadiusX(60.0f);
        arc1.setRadiusY(60.0f);
        arc1.setStartAngle(45.0f);
        arc1.setLength(90.0f);
        arc1.setStroke(Color.WHITE);
        arc1.setStrokeWidth(10);
        arc1.setFill(Color.TRANSPARENT);
        arc1.setType(ArcType.OPEN);
        movePivot(arc1, 0.0f, 50.0f);
    }
    RotateTransition rotate1 = new RotateTransition();

    {

        rotate1.setByAngle(360);
        rotate1.setCycleCount(Timeline.INDEFINITE);
        rotate1.setDuration(Duration.millis(3000));
        rotate1.setAutoReverse(false);
        rotate1.setNode(arc1);
        rotate1.play();
    }
    Arc  arc2= new Arc();
    {
        arc2.setCenterX(200.0f);
        arc2.setCenterY(200.0f);
        arc2.setRadiusX(60.0f);
        arc2.setRadiusY(60.0f);
        arc2.setStartAngle(135.0f);
        arc2.setLength(90.0f);
        arc2.setStroke(Color.RED);
        arc2.setStrokeWidth(10);
        arc2.setFill(Color.TRANSPARENT);
        arc2.setType(ArcType.OPEN);
        movePivot(arc2, 50.0f, 0.0f);
    }
    RotateTransition rotate2 = new RotateTransition();

    {
        //rotate2.setAxis(Rotate.Z_AXIS);
        rotate2.setByAngle(360);
        rotate2.setCycleCount(Timeline.INDEFINITE);
        rotate2.setDuration(Duration.millis(3000));
        rotate2.setAutoReverse(false);
        rotate2.setNode(arc2);
        rotate2.play();
    }
    Arc  arc3= new Arc();
    {
        arc3.setCenterX(200.0f);
        arc3.setCenterY(200.0f);
        arc3.setRadiusX(60.0f);
        arc3.setRadiusY(60.0f);
        arc3.setStartAngle(225.0f);
        arc3.setLength(90.0f);
        arc3.setStroke(Color.PINK);
        arc3.setStrokeWidth(10);
        arc3.setFill(Color.TRANSPARENT);
        arc3.setType(ArcType.OPEN);
        movePivot(arc3, 0.0f, -50.0f);
    }
    RotateTransition rotate3= new RotateTransition();

    {

        rotate3.setByAngle(360);
        rotate3.setCycleCount(Timeline.INDEFINITE);
        rotate3.setDuration(Duration.millis(3000));
        rotate3.setAutoReverse(false);
        rotate3.setNode(arc3);
        rotate3.play();
    }
    Arc  arc4= new Arc();
    {
        arc4.setCenterX(200.0f);
        arc4.setCenterY(200.0f);
        arc4.setRadiusX(60.0f);
        arc4.setRadiusY(60.0f);
        arc4.setStartAngle(315.0f);
        arc4.setLength(90.0f);
        arc4.setStroke(Color.YELLOW);
        arc4.setStrokeWidth(10);
        arc4.setFill(Color.TRANSPARENT);
        arc4.setType(ArcType.OPEN);
        movePivot(arc4, -50.0f, 0.0f);
    }
    RotateTransition rotate4 = new RotateTransition();

    {

        rotate4.setByAngle(360);
        rotate4.setCycleCount(Timeline.INDEFINITE);
        rotate4.setDuration(Duration.millis(3000));
        rotate4.setAutoReverse(false);
        rotate4.setNode(arc4);
        rotate4.play();
    }
    private void movePivot(Node node, double x, double y){
        node.getTransforms().add(new Translate(-x,-y));
        node.setTranslateX(x); node.setTranslateY(y);
    }



    Group ball = new Group();

    {
        ball.getChildren().add(arc1);
        ball.getChildren().add(arc2);
        ball.getChildren().add(arc3);
        ball.getChildren().add(arc4);

    }
    public circle() {
    }
}
