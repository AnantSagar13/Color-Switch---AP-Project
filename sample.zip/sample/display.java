package sample;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class display {
    Group game_objects = new Group();
    Group game_objects_ball = new Group();

    circle c;
    {c = new circle();}

    ball b=new ball();
    Scene scene2;
    Scene scene3=new Scene(game_objects_ball, 250, 300, Color.BLACK);
    Stage stage=page.stage;
    Button Button4;
    {
        Button4=new Button();
        Button4.setPrefSize(70,70);
        Button4.setText("||");
        Font font= Font.loadFont(getClass()
                .getResourceAsStream("fonts/font3.ttf"), 25);
       Button4.setFont(font);
      Button4.setStyle("-fx-text-fill: black; ");
        Button4.setLayoutX(375);
        Button4.setLayoutY(10);

        BackgroundImage backgroundImage = new BackgroundImage( new Image( getClass().getResource("17.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background = new Background(backgroundImage);
        BackgroundImage backgroundImage1 = new BackgroundImage( new Image( getClass().getResource("16.jpg").toExternalForm()), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        Background background2 = new Background(backgroundImage1);
        Button4.setOnMouseEntered(e -> Button4.setBackground(background2));
        Button4.setOnMouseExited(e -> Button4.setBackground(background));
        Button4.setBackground(background);
        Button4.setOnMouseClicked(e -> {
            /*mainPage p=new mainPage(stage);
            stage.setScene(p.scene);
            stage.show();*/
            game_objects.setEffect(new GaussianBlur());

            pauseMenu p=new pauseMenu(stage);
            Stage popupStage = new Stage(StageStyle.TRANSPARENT);
            {
                popupStage.initOwner(stage);
                popupStage.initModality(Modality.APPLICATION_MODAL);

                popupStage.setScene(p.scene);
                popupStage.show();
            }
            p.Button1.setOnMouseClicked(event -> {
            game_objects.setEffect(null);
                //animation.play();
                popupStage.hide();
            });
            p.Button3.setOnMouseClicked(f -> {
                game_objects.setEffect(null);
                popupStage.hide();
                mainPage q=new mainPage(stage);
                stage.setScene(q.scene);
                stage.show();

            });

        });

    }
    {
        game_objects.getChildren().addAll(c.ball, b.ball,Button4);
        //game_objects_ball.getChildren().addAll(c.ball);
        scene2 = new Scene(game_objects, 450, 500, Color.BLACK);
    }

    {
        scene2.setOnKeyPressed(f -> {
            switch (f.getCode()) {
                case W:
                    b.move();

                    break;
                case F:
                  endGamePage p= new endGamePage(stage);
                  stage.setScene(p.scene);
                  stage.show();
                  break;
            }

        });
    }

    public display() {

    }


}
